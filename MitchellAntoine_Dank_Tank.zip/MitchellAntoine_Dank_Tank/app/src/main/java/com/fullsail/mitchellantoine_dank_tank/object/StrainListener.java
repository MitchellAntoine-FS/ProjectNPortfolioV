package com.fullsail.mitchellantoine_dank_tank.object;

import java.util.ArrayList;

public interface StrainListener {
    ArrayList<Strains> getStrains();

    void getSelectedStrain(int position);


}
