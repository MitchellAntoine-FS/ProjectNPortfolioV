package com.fullsail.mitchellantoine_dank_tank.object;

public interface LogInListener {
    void closeLogIn();
}
