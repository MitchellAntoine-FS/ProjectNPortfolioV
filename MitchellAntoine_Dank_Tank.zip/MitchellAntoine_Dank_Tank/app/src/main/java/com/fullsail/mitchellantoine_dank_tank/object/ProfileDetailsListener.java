package com.fullsail.mitchellantoine_dank_tank.object;

public interface ProfileDetailsListener {
    Strains getStrain();
}
