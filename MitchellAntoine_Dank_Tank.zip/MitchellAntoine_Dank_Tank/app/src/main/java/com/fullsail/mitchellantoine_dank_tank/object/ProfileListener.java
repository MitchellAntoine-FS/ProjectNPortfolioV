package com.fullsail.mitchellantoine_dank_tank.object;

public interface ProfileListener {

    void getStrainPosition(Strains strain, int position);
}
