Dank Tank
==============================

Installation Introductions 
--------------------------

1. Drag the apk to your android emulator, the app will install automaticly.
2. Open your app drawer by swipping up, or open you settings/ apps/
3. Select Dank Tank to open the app

Hardware Requirements
---------------------

Android emulator or phone
Android 7.1 Nougat or higher

Log In Requierments For Testing
-------------------------------

Create an account to log in.

Known bugs
----------
No known bugs.



